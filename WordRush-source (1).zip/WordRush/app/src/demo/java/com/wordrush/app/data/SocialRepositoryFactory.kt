package com.wordrush.app.data

import android.content.Context

object SocialRepositoryFactory {
    fun create(context: Context): SocialRepository = DemoSocialRepository()
}
