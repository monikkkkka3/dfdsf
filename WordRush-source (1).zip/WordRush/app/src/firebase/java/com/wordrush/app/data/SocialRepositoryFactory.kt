package com.wordrush.app.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.wordrush.app.model.Competition
import com.wordrush.app.model.Player
import kotlinx.coroutines.tasks.await

class FirebaseSocialRepository(
    private val auth: FirebaseAuth,
    private val db: FirebaseFirestore,
) : SocialRepository {
    private val userId: String
        get() = requireNotNull(auth.currentUser?.uid) { "A signed-in Firebase user is required" }

    override suspend fun currentPlayer(): Player =
        db.collection("users").document(userId).get().await().toObject(Player::class.java)
            ?: error("Player profile not found")

    override suspend fun followers(): List<Player> {
        val followingIds = db.collection("users").document(userId)
            .collection("following").get().await().documents.map { it.id }
        if (followingIds.isEmpty()) return emptyList()
        return followingIds.chunked(10).flatMap { ids ->
            db.collection("users").whereIn("id", ids).get().await().toObjects(Player::class.java)
        }
    }

    override suspend fun competitions(): List<Competition> =
        db.collection("competitions")
            .whereArrayContains("playerIds", userId)
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .get().await().toObjects(Competition::class.java)

    override suspend fun follow(playerId: String) {
        db.collection("users").document(userId).collection("following")
            .document(playerId).set(mapOf("createdAt" to System.currentTimeMillis())).await()
    }

    override suspend fun sendChallenge(opponentId: String, category: String, rounds: Int) {
        db.collection("competitions").add(
            mapOf(
                "playerIds" to listOf(userId, opponentId),
                "challengerId" to userId,
                "opponentId" to opponentId,
                "category" to category,
                "rounds" to rounds,
                "status" to "PENDING",
                "createdAt" to System.currentTimeMillis(),
                "updatedAt" to System.currentTimeMillis(),
            )
        ).await()
    }
}

object SocialRepositoryFactory {
    fun create(context: Context): SocialRepository =
        if (FirebaseApp.getApps(context).isNotEmpty()) {
            FirebaseSocialRepository(FirebaseAuth.getInstance(), FirebaseFirestore.getInstance())
        } else {
            DemoSocialRepository()
        }
}
