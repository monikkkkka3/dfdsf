package com.wordrush.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.Player
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Avatar
import com.wordrush.app.ui.components.PrimaryAction
import com.wordrush.app.ui.components.SelectionRow
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple

private data class BattleCategory(
    val id: String,
    val title: String,
    val emoji: String,
    val description: String,
    val color: Color,
)

@Composable
fun ChallengeSetupScreen(
    onBack: () -> Unit,
    onStart: (String) -> Unit,
) {
    val categories = remember {
        listOf(
            BattleCategory("spelling", "Spelling Bee", "🔊", "Hear it and spell it", Coral),
            BattleCategory("anagrams", "Anagram Rush", "🔀", "Unscramble under pressure", RushPurple),
            BattleCategory("definitions", "Definition Dash", "💡", "Match words and meanings", Gold),
            BattleCategory("mixed", "Mixed Bag", "🎲", "A little of everything", Mint),
        )
    }
    var selectedPlayer by remember { mutableStateOf<Player?>(SampleData.followers.first()) }
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var rounds by remember { mutableIntStateOf(5) }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(43.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                ) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Spacer(Modifier.size(12.dp))
                Column {
                    Text("New challenge", style = MaterialTheme.typography.headlineMedium)
                    Text("Set the rules, then send it", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            SetupSection("1", "Choose a rival") {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SampleData.followers.forEach { player ->
                        RivalChoice(
                            player = player,
                            selected = selectedPlayer?.id == player.id,
                            onClick = { selectedPlayer = player }
                        )
                    }
                }
            }
        }

        item {
            SetupSection("2", "Pick a game") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    categories.forEach { category ->
                        SelectionRow(
                            title = category.title,
                            subtitle = category.description,
                            selected = category == selectedCategory,
                            onClick = { selectedCategory = category },
                            leading = {
                                Box(
                                    Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(category.color.copy(alpha = .14f)),
                                    contentAlignment = Alignment.Center
                                ) { Text(category.emoji, fontSize = 23.sp) }
                            }
                        )
                    }
                }
            }
        }

        item {
            SetupSection("3", "Number of rounds") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(5.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    listOf(3, 5, 7).forEach { count ->
                        val selected = rounds == count
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (selected) RushPurple else Color.Transparent)
                                .clickable { rounds = count }
                                .padding(vertical = 13.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$count rounds",
                                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        item {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(10.dp))
                    Text(
                        "Both players get the same words. Scores are revealed after every round.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item {
            PrimaryAction(
                text = "Challenge ${selectedPlayer?.name ?: "a friend"}",
                onClick = { selectedPlayer?.let { onStart(it.id) } },
                modifier = Modifier.fillMaxWidth(),
                enabled = selectedPlayer != null
            )
        }
        item { Spacer(Modifier.height(6.dp)) }
    }
}

@Composable
private fun SetupSection(number: String, title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(27.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(number, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.size(9.dp))
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        content()
    }
}

@Composable
private fun RivalChoice(player: Player, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .size(width = 100.dp, height = 125.dp)
            .clickable(onClick = onClick)
    ) {
        Box {
            Column(
                Modifier.padding(12.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(player, 52.dp, showStatus = true)
                Spacer(Modifier.height(8.dp))
                Text(player.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text("${player.wins} wins", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(7.dp)
                        .size(21.dp)
                        .clip(CircleShape)
                        .background(RushPurple),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
            }
        }
    }
}
