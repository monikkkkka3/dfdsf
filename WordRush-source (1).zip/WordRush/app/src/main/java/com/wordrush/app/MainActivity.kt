package com.wordrush.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.wordrush.app.ui.WordRushApp
import com.wordrush.app.ui.theme.WordRushTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WordRushTheme {
                WordRushApp()
            }
        }
    }
}
