package com.wordrush.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.Achievement
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Avatar
import com.wordrush.app.ui.components.SectionHeader
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple

@Composable
fun ProfileScreen() {
    val player = SampleData.currentPlayer
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(21.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your profile", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
                IconButton(
                    onClick = {},
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                ) { Icon(Icons.Rounded.Settings, "Settings") }
            }
        }

        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box {
                    Avatar(player, 88.dp)
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Edit, null, tint = Color.White, modifier = Modifier.size(15.dp)) }
                }
                Spacer(Modifier.height(12.dp))
                Text(player.name + " Chen", style = MaterialTheme.typography.headlineMedium)
                Text(player.handle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(9.dp))
                Text("Word nerd • friendly rival • 12-day streak 🔥", style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(vertical = 18.dp)) {
                    Stat("${player.wins}", "Wins", Modifier.weight(1f))
                    DividerDot()
                    Stat("184", "Followers", Modifier.weight(1f))
                    DividerDot()
                    Stat("72%", "Win rate", Modifier.weight(1f))
                }
            }
        }

        item { LevelCard() }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Achievements", "See all") {}
                SampleData.achievements.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { achievement -> AchievementCard(achievement, Modifier.weight(1f)) }
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("PREFERENCES", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface) {
                    Column {
                        SettingsRow(Icons.Rounded.Notifications, "Notifications", "Challenges and streak reminders")
                        SettingsRow(Icons.Rounded.PrivacyTip, "Privacy", "Followers can challenge me")
                        SettingsRow(Icons.Rounded.Settings, "Game preferences", "Sound, haptics, difficulty")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DividerDot() {
    Box(Modifier.size(1.dp, 36.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .5f)))
}

@Composable
private fun LevelCard() {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(51.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(RushPurple),
                    contentAlignment = Alignment.Center
                ) { Text("12", color = Color.White, style = MaterialTheme.typography.titleLarge) }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Vocabulary Voyager", style = MaterialTheme.typography.titleMedium)
                    Text("Level 12", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("2,840 XP", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { .68f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                color = RushPurple,
                trackColor = MaterialTheme.colorScheme.surface.copy(alpha = .65f)
            )
            Spacer(Modifier.height(7.dp))
            Row {
                Text("660 XP to Level 13", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text("68%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun AchievementCard(achievement: Achievement, modifier: Modifier) {
    Surface(
        shape = RoundedCornerShape(19.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.alpha(if (achievement.unlocked) 1f else .45f)
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (achievement.unlocked) Gold.copy(alpha = .18f) else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) { Text(achievement.emoji, fontSize = 22.sp) }
            Spacer(Modifier.height(7.dp))
            Text(achievement.title, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(41.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(21.dp)) }
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Rounded.ArrowForwardIos, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
