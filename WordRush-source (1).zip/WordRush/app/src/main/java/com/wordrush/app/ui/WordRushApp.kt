package com.wordrush.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.screens.ArenaScreen
import com.wordrush.app.ui.screens.ChallengeSetupScreen
import com.wordrush.app.ui.screens.HomeScreen
import com.wordrush.app.ui.screens.ProfileScreen
import com.wordrush.app.ui.screens.PuzzleGameScreen
import com.wordrush.app.ui.screens.PuzzlesScreen
import com.wordrush.app.ui.screens.SpellingBattleScreen

data class BottomDestination(val route: String, val label: String, val icon: ImageVector)

private val bottomDestinations = listOf(
    BottomDestination("home", "Home", Icons.Rounded.Home),
    BottomDestination("puzzles", "Puzzles", Icons.Rounded.Extension),
    BottomDestination("arena", "Arena", Icons.Rounded.EmojiEvents),
    BottomDestination("profile", "Profile", Icons.Rounded.Person),
)

@Composable
fun WordRushApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: "home"
    val showBottomBar = bottomDestinations.any { it.route == currentRoute }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    bottomDestinations.forEach { destination ->
                        val selected = currentRoute == destination.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(destination.icon, destination.label) },
                            label = { Text(destination.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(
                    onOpenPuzzle = { navController.navigate("game/$it") },
                    onOpenArena = { navController.navigate("arena") },
                    onOpenProfile = { navController.navigate("profile") },
                )
            }
            composable("puzzles") {
                PuzzlesScreen(onOpenPuzzle = { navController.navigate("game/$it") })
            }
            composable("arena") {
                ArenaScreen(
                    onCreateChallenge = { navController.navigate("challenge") },
                    onOpenBattle = { playerId -> navController.navigate("battle/$playerId") }
                )
            }
            composable("profile") { ProfileScreen() }
            composable(
                route = "game/{modeId}",
                arguments = listOf(navArgument("modeId") { type = NavType.StringType })
            ) { entry ->
                PuzzleGameScreen(
                    modeId = entry.arguments?.getString("modeId") ?: "anagram",
                    onBack = navController::popBackStack
                )
            }
            composable("challenge") {
                ChallengeSetupScreen(
                    onBack = navController::popBackStack,
                    onStart = { playerId ->
                        navController.navigate("battle/$playerId") {
                            popUpTo("challenge") { inclusive = true }
                        }
                    }
                )
            }
            composable(
                route = "battle/{playerId}",
                arguments = listOf(navArgument("playerId") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("playerId")
                val opponent = SampleData.followers.firstOrNull { it.id == id } ?: SampleData.followers.first()
                SpellingBattleScreen(opponent = opponent, onBack = navController::popBackStack)
            }
        }
    }
}
