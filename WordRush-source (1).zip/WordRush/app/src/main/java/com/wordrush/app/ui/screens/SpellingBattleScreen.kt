package com.wordrush.app.ui.screens

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.Player
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Avatar
import com.wordrush.app.ui.components.PrimaryAction
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple
import kotlinx.coroutines.delay
import java.util.Locale

private data class SpellingWord(val word: String, val definition: String, val sentence: String)

private val battleWords = listOf(
    SpellingWord("necessary", "Needed or required", "It is necessary to practice before the competition."),
    SpellingWord("rhythm", "A repeated pattern of sound or movement", "The drummer kept a steady rhythm."),
    SpellingWord("separate", "To divide or keep apart", "Please separate the light and dark clothes."),
    SpellingWord("confident", "Sure of yourself or your abilities", "She felt confident before the final round."),
    SpellingWord("achievement", "Something accomplished successfully", "Finishing the puzzle was a proud achievement."),
)

@Composable
fun SpellingBattleScreen(opponent: Player, onBack: () -> Unit) {
    var roundIndex by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var wasCorrect by remember { mutableStateOf(false) }
    var yourScore by remember { mutableIntStateOf(0) }
    var opponentScore by remember { mutableIntStateOf(0) }
    var roundTime by remember { mutableIntStateOf(20) }
    var finished by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val word = battleWords[roundIndex]

    LaunchedEffect(roundIndex, finished) {
        if (!finished) {
            roundTime = 20
            while (roundTime > 0 && !submitted) {
                delay(1_000)
                roundTime--
            }
            if (roundTime == 0 && !submitted) {
                submitted = true
                wasCorrect = false
                opponentScore += listOf(80, 100, 90, 100, 110)[roundIndex]
            }
        }
    }

    fun submitAnswer() {
        if (submitted || input.isBlank()) return
        focus.clearFocus()
        wasCorrect = input.trim().equals(word.word, ignoreCase = true)
        submitted = true
        if (wasCorrect) yourScore += 100 + roundTime * 3
        opponentScore += listOf(80, 100, 90, 100, 110)[roundIndex]
    }

    fun nextRound() {
        if (roundIndex == battleWords.lastIndex) {
            finished = true
        } else {
            roundIndex++
            input = ""
            submitted = false
            wasCorrect = false
        }
    }

    if (finished) {
        BattleResultScreen(
            opponent = opponent,
            yourScore = yourScore,
            opponentScore = opponentScore,
            onDone = onBack
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.size(43.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
            ) { Icon(Icons.Rounded.ArrowBack, "Leave battle") }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("Spelling showdown", style = MaterialTheme.typography.titleLarge)
                Text("Live with ${opponent.name}", style = MaterialTheme.typography.bodyMedium, color = Mint)
            }
            Tag("ROUND ${roundIndex + 1}/5", RushPurple)
        }

        Spacer(Modifier.height(22.dp))
        BattleScoreboard(opponent, yourScore, opponentScore)
        Spacer(Modifier.height(18.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${roundTime}s", color = if (roundTime <= 5) Coral else MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.width(10.dp))
            LinearProgressIndicator(
                progress = { roundTime / 20f },
                modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape),
                color = if (roundTime <= 5) Coral else RushPurple,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }

        Spacer(Modifier.height(20.dp))
        PronunciationCard(word)
        Spacer(Modifier.height(18.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { if (!submitted) input = it.filter(Char::isLetter) },
            modifier = Modifier.fillMaxWidth(),
            enabled = !submitted,
            singleLine = true,
            label = { Text("Spell the word") },
            placeholder = { Text("Type what you hear") },
            isError = submitted && !wasCorrect,
            textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
            trailingIcon = {
                if (submitted) {
                    Icon(
                        if (wasCorrect) Icons.Rounded.CheckCircle else Icons.Rounded.Close,
                        null,
                        tint = if (wasCorrect) Mint else Coral
                    )
                }
            },
            supportingText = {
                if (submitted) {
                    if (wasCorrect) Text("Correct! Great spelling.", color = Mint)
                    else Text("The correct spelling is “${word.word}”.", color = Coral)
                } else {
                    Text("Capitalization does not matter")
                }
            },
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RushPurple,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                disabledContainerColor = MaterialTheme.colorScheme.surface,
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { submitAnswer() })
        )

        Spacer(Modifier.height(15.dp))
        PrimaryAction(
            text = if (submitted) {
                if (roundIndex == battleWords.lastIndex) "See results" else "Next round"
            } else "Lock in spelling",
            onClick = { if (submitted) nextRound() else submitAnswer() },
            enabled = submitted || input.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(18.dp))
        Surface(shape = RoundedCornerShape(19.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("🛡️", fontSize = 22.sp)
                Spacer(Modifier.width(10.dp))
                Text(
                    "Words and scoring are identical for both players. Answers lock when the timer ends.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun BattleScoreboard(opponent: Player, yourScore: Int, opponentScore: Int) {
    Surface(shape = RoundedCornerShape(25.dp), color = MaterialTheme.colorScheme.surface) {
        Row(
            Modifier.fillMaxWidth().padding(17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(SampleData.currentPlayer, 51.dp)
                Spacer(Modifier.height(5.dp))
                Text("You", style = MaterialTheme.typography.labelLarge)
                Text(yourScore.toString(), style = MaterialTheme.typography.headlineMedium, color = RushPurple)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("VS", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("⚡", fontSize = 24.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(opponent, 51.dp, showStatus = true)
                Spacer(Modifier.height(5.dp))
                Text(opponent.name, style = MaterialTheme.typography.labelLarge)
                Text(opponentScore.toString(), style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}

@Composable
private fun PronunciationCard(word: SpellingWord) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.US
                tts = engine
            }
        }
        onDispose {
            engine?.stop()
            engine?.shutdown()
        }
    }
    fun speak(text: String, id: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    Surface(shape = RoundedCornerShape(27.dp), color = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier.fillMaxWidth().padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(92.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(RushPurple, Color(0xFF8E72FF))))
                    .clickable { speak(word.word, "battle_word") },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(72.dp).clip(CircleShape)
                        .border(1.dp, Color.White.copy(alpha = .35f), CircleShape)
                )
                Icon(Icons.Rounded.VolumeUp, "Hear word", tint = Color.White, modifier = Modifier.size(39.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("Tap to hear the word", style = MaterialTheme.typography.titleMedium)
            Text("You can replay it as many times as you need", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(17.dp))
            Surface(
                shape = RoundedCornerShape(15.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth().clickable { speak(word.sentence, "battle_sentence") }
            ) {
                Column(Modifier.padding(13.dp)) {
                    Text("DEFINITION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(word.definition, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(6.dp))
                    Text("▶ Hear it in a sentence", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun BattleResultScreen(opponent: Player, yourScore: Int, opponentScore: Int, onDone: () -> Unit) {
    val won = yourScore >= opponentScore
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(118.dp).clip(CircleShape)
                .background((if (won) Gold else RushPurple).copy(alpha = .18f)),
            contentAlignment = Alignment.Center
        ) { Text(if (won) "🏆" else "🤝", fontSize = 61.sp) }
        Spacer(Modifier.height(20.dp))
        Text(if (won) "You won!" else "Great match!", style = MaterialTheme.typography.headlineLarge)
        Text("Spelling showdown vs ${opponent.name}", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(21.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(yourScore.toString(), style = MaterialTheme.typography.headlineLarge, color = RushPurple)
                    Text("YOU", style = MaterialTheme.typography.labelMedium)
                }
                Text("—", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(opponentScore.toString(), style = MaterialTheme.typography.headlineLarge)
                    Text(opponent.name.uppercase(), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Tag(if (won) "+250 XP  •  Win streak +1" else "+100 XP  •  Nice effort", if (won) Gold else RushPurple)
        Spacer(Modifier.height(24.dp))
        PrimaryAction("Back to arena", onDone, Modifier.fillMaxWidth())
    }
}
