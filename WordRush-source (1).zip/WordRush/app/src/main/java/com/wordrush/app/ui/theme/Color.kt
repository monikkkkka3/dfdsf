package com.wordrush.app.ui.theme

import androidx.compose.ui.graphics.Color

val RushPurple = Color(0xFF6C4CF6)
val DeepPurple = Color(0xFF4A2ED0)
val Ink = Color(0xFF201A3A)
val MutedInk = Color(0xFF716C82)
val Cloud = Color(0xFFF8F6FF)
val Lavender = Color(0xFFE9E3FF)
val Coral = Color(0xFFFF6B6B)
val Gold = Color(0xFFFFC857)
val Mint = Color(0xFF3ED6A2)
val Sky = Color(0xFF5CB8FF)
val Night = Color(0xFF161229)
val NightSurface = Color(0xFF211C3A)
