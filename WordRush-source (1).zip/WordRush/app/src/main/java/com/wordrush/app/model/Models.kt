package com.wordrush.app.model

import androidx.compose.ui.graphics.Color
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple
import com.wordrush.app.ui.theme.Sky

data class Player(
    val id: String = "",
    val name: String = "",
    val handle: String = "",
    val initials: String = "",
    val xp: Int = 0,
    val wins: Int = 0,
    val streak: Int = 0,
    val online: Boolean = false,
    val avatarColorHex: Long = 0xFF6C4CF6,
) {
    val avatarColor: Color get() = Color(avatarColorHex)
}

data class PuzzleMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val emoji: String,
    val accent: Color,
    val difficulty: String,
    val bestScore: Int? = null,
    val locked: Boolean = false,
)

data class WordRound(
    val answer: String,
    val clue: String,
    val scrambled: String,
    val hint: String,
)

data class Competition(
    val id: String = "",
    val opponent: Player = Player(),
    val category: String = "",
    val yourScore: Int = 0,
    val opponentScore: Int = 0,
    val totalRounds: Int = 0,
    val status: CompetitionStatus = CompetitionStatus.WAITING,
    val timeLabel: String = "",
)

enum class CompetitionStatus { YOUR_TURN, WAITING, WON, LIVE }

data class Achievement(
    val emoji: String,
    val title: String,
    val unlocked: Boolean,
)

object SampleData {
    val currentPlayer = Player(
        id = "maya", name = "Maya", handle = "@mayawords", initials = "M",
        xp = 2840, wins = 47, streak = 12, online = true, avatarColorHex = 0xFFFF6B6B
    )

    val followers = listOf(
        Player("jordan", "Jordan", "@wordwiz", "JD", 3210, 62, 8, true, 0xFF5CB8FF),
        Player("nia", "Nia", "@niasays", "NI", 2760, 39, 15, true, 0xFF3ED6A2),
        Player("caleb", "Caleb", "@spellcal", "CA", 2450, 31, 6, false, 0xFFFFC857),
        Player("zoe", "Zoe", "@zoevocab", "ZO", 3600, 78, 21, true, 0xFFA786F8),
        Player("sam", "Sam", "@samgrams", "SA", 1980, 24, 4, false, 0xFFFF8C6B),
    )

    val puzzleModes = listOf(
        PuzzleMode("anagram", "Anagram Rush", "Unscramble before time runs out", "🔀", RushPurple, "Medium", 1840),
        PuzzleMode("spelling", "Spelling Sprint", "Hear it, spell it, own it", "🔊", Coral, "Adaptive", 920),
        PuzzleMode("ladder", "Word Ladder", "Change one letter at a time", "🪜", Mint, "Clever", 1260),
        PuzzleMode("definition", "Definition Dash", "Find the word that fits", "💡", Gold, "Medium", 740),
        PuzzleMode("wordhunt", "Word Hunt", "Discover hidden words", "🔎", Sky, "Relaxed", 2150),
        PuzzleMode("crossword", "Mini Crossword", "A quick daily grid", "✏️", Color(0xFFA786F8), "Daily", locked = true),
    )

    val competitions = listOf(
        Competition("c1", followers[0], "Spelling • 5 rounds", 3, 2, 5, CompetitionStatus.YOUR_TURN, "2h left"),
        Competition("c2", followers[1], "Anagrams • 7 rounds", 4, 4, 7, CompetitionStatus.WAITING, "Waiting on Nia"),
        Competition("c3", followers[3], "Definitions • 5 rounds", 5, 3, 5, CompetitionStatus.WON, "Yesterday"),
    )

    val anagrams = listOf(
        WordRound("planet", "A world orbiting a star", "TENALP", "It starts with P"),
        WordRound("bright", "Giving off lots of light", "THGIRB", "Opposite of dim"),
        WordRound("journey", "Travel from one place to another", "RYJNEOU", "Seven letters"),
        WordRound("whisper", "To speak very softly", "SREPWИH".replace("И", "I"), "A quiet way to talk"),
        WordRound("victory", "Success in a competition", "TOVRYIC", "What winners earn"),
    )

    val definitions = listOf(
        WordRound("curious", "Eager to know or learn something", "SUOIURC", "It begins with C"),
        WordRound("swift", "Moving or capable of moving very quickly", "TFSWI", "Five letters"),
        WordRound("fragile", "Easily broken or damaged", "LIFAGER", "Handle with care"),
        WordRound("vivid", "Producing powerful feelings or strong, clear images", "DIVIV", "Bright and intense"),
    )

    val ladderRounds = listOf(
        WordRound("warm", "Change COLD → CORD → CARD → WARD → ?", "", "Cozy, not cold"),
        WordRound("moon", "Change SOON by one letter: Earth's night companion", "", "Look up at night"),
        WordRound("tide", "Change RIDE by one letter: ocean's rise and fall", "", "Moved by the moon"),
    )

    val achievements = listOf(
        Achievement("🔥", "7-day streak", true),
        Achievement("⚡", "Quick thinker", true),
        Achievement("🏆", "25 wins", true),
        Achievement("🧠", "Word scholar", true),
        Achievement("💯", "Perfect round", false),
        Achievement("👑", "Top 10", false),
    )
}
