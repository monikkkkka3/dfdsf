package com.wordrush.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = RushPurple,
    onPrimary = Color.White,
    primaryContainer = Lavender,
    onPrimaryContainer = Ink,
    secondary = Coral,
    tertiary = Mint,
    background = Cloud,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF0EDF8),
    onSurfaceVariant = MutedInk,
    outline = Color(0xFFD8D2E6),
    error = Color(0xFFE6495C)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA996FF),
    onPrimary = Night,
    primaryContainer = Color(0xFF3C2A8E),
    secondary = Color(0xFFFF9292),
    tertiary = Mint,
    background = Night,
    onBackground = Color(0xFFF5F1FF),
    surface = NightSurface,
    onSurface = Color(0xFFF5F1FF),
    surfaceVariant = Color(0xFF302A4C),
    onSurfaceVariant = Color(0xFFC9C3D9),
    outline = Color(0xFF554E6B)
)

@Composable
fun WordRushTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = colors.surface.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
    MaterialTheme(
        colorScheme = colors,
        typography = WordRushTypography,
        shapes = WordRushShapes,
        content = content
    )
}
