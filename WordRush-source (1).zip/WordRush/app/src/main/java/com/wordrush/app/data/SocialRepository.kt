package com.wordrush.app.data

import com.wordrush.app.model.Competition
import com.wordrush.app.model.Player
import com.wordrush.app.model.SampleData

/**
 * All social data passes through this interface. The demo flavor is immediately playable,
 * while the optional Firebase flavor supplies its own cloud-backed implementation.
 */
interface SocialRepository {
    suspend fun currentPlayer(): Player
    suspend fun followers(): List<Player>
    suspend fun competitions(): List<Competition>
    suspend fun follow(playerId: String)
    suspend fun sendChallenge(opponentId: String, category: String, rounds: Int)
}

class DemoSocialRepository : SocialRepository {
    override suspend fun currentPlayer() = SampleData.currentPlayer
    override suspend fun followers() = SampleData.followers
    override suspend fun competitions() = SampleData.competitions
    override suspend fun follow(playerId: String) = Unit
    override suspend fun sendChallenge(opponentId: String, category: String, rounds: Int) = Unit
}
