package com.wordrush.app

import android.app.Application
import com.wordrush.app.data.SocialRepositoryFactory

class WordRushApplication : Application() {
    val socialRepository by lazy { SocialRepositoryFactory.create(this) }
}
