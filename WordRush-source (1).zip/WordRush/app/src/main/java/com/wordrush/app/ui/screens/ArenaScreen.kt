package com.wordrush.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.People
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.Competition
import com.wordrush.app.model.CompetitionStatus
import com.wordrush.app.model.Player
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Avatar
import com.wordrush.app.ui.components.SectionHeader
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple

@Composable
fun ArenaScreen(
    onCreateChallenge: () -> Unit,
    onOpenBattle: (String) -> Unit,
) {
    var tab by remember { mutableStateOf("Active") }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(21.dp)
    ) {
        item {
            Column {
                Text("COMPETE", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text("The Word Arena", style = MaterialTheme.typography.headlineMedium)
                Text("Challenge friends. Climb the ranks.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item { RankHero(onQuickMatch = { onOpenBattle(SampleData.followers.first().id) }) }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Followers", "View all") {}
                LazyRow(horizontalArrangement = Arrangement.spacedBy(15.dp)) {
                    item { AddFollowerButton() }
                    items(SampleData.followers) { player ->
                        FollowerBubble(player = player, onClick = { onOpenBattle(player.id) })
                    }
                }
            }
        }

        item {
            Button(
                onClick = onCreateChallenge,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RushPurple)
            ) {
                Icon(Icons.Rounded.Add, null)
                Spacer(Modifier.width(9.dp))
                Text("Create a challenge", style = MaterialTheme.typography.titleMedium)
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(4.dp)
            ) {
                listOf("Active", "Completed").forEach { label ->
                    val selected = tab == label
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(13.dp))
                            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .clickable { tab = label }
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        val filtered = if (tab == "Active") SampleData.competitions.filter { it.status != CompetitionStatus.WON }
        else SampleData.competitions.filter { it.status == CompetitionStatus.WON }
        items(filtered.size) { index ->
            ArenaCompetitionCard(filtered[index], onClick = { onOpenBattle(filtered[index].opponent.id) })
        }

        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun RankHero(onQuickMatch: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF252042), Color(0xFF48369C))
                )
            )
            .padding(20.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(57.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Gold.copy(alpha = .2f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.EmojiEvents, null, tint = Gold, modifier = Modifier.size(33.dp)) }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text("Gold League", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text("#128 this week  •  ↑ 24", color = Mint, style = MaterialTheme.typography.labelMedium)
                }
                Text("2,840", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            }
            Spacer(Modifier.height(19.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onQuickMatch,
                    modifier = Modifier.weight(1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .35f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Rounded.Bolt, null, tint = Gold, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Quick match")
                }
                Surface(color = Color.White.copy(alpha = .10f), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(horizontal = 15.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.People, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("12 online", color = Color.White, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun FollowerBubble(player: Player, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(60.dp)
            .clickable(onClick = onClick)
    ) {
        Avatar(player, size = 54.dp, showStatus = true)
        Spacer(Modifier.height(6.dp))
        Text(player.name, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
private fun AddFollowerButton() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(60.dp)) {
        Box(
            Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer)
                .clickable {},
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.height(6.dp))
        Text("Find", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun ArenaCompetitionCard(competition: Competition, onClick: () -> Unit) {
    val statusColor = when (competition.status) {
        CompetitionStatus.YOUR_TURN -> Coral
        CompetitionStatus.WAITING -> Gold
        CompetitionStatus.WON -> Mint
        CompetitionStatus.LIVE -> RushPurple
    }
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(competition.opponent, size = 48.dp, showStatus = true)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Maya vs ${competition.opponent.name}", style = MaterialTheme.typography.titleMedium)
                    Text(competition.category, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Rounded.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Tag(
                    when (competition.status) {
                        CompetitionStatus.YOUR_TURN -> "YOUR TURN"
                        CompetitionStatus.WAITING -> "WAITING"
                        CompetitionStatus.WON -> "YOU WON"
                        CompetitionStatus.LIVE -> "LIVE"
                    },
                    statusColor
                )
                Spacer(Modifier.weight(1f))
                Text("${competition.yourScore} — ${competition.opponentScore}", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.width(12.dp))
                Text(competition.timeLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
