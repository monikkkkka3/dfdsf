package com.wordrush.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.Competition
import com.wordrush.app.model.CompetitionStatus
import com.wordrush.app.model.PuzzleMode
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Avatar
import com.wordrush.app.ui.components.SectionHeader
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.components.XpPill
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.DeepPurple
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple

@Composable
fun HomeScreen(
    onOpenPuzzle: (String) -> Unit,
    onOpenArena: () -> Unit,
    onOpenProfile: () -> Unit,
) {
    val player = SampleData.currentPlayer
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HEY, ${player.name.uppercase()}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Ready to wordplay?", style = MaterialTheme.typography.headlineMedium)
                }
                XpPill(player.xp)
                Spacer(Modifier.width(8.dp))
                Box {
                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface)
                    ) { Icon(Icons.Rounded.Notifications, "Notifications") }
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(Coral)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Avatar(player, size = 44.dp, modifier = Modifier.clickable(onClick = onOpenProfile))
            }
        }

        item { StreakHero(streak = player.streak, onPlay = { onOpenPuzzle("anagram") }) }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Today's challenge", "View all") { onOpenPuzzle("anagram") }
                DailyChallengeCard(onClick = { onOpenPuzzle("definition") })
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Play your way", "All puzzles") { onOpenPuzzle("anagram") }
                LazyRow(
                    contentPadding = PaddingValues(end = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(SampleData.puzzleModes.take(4)) { mode ->
                        QuickModeCard(mode = mode, onClick = { onOpenPuzzle(mode.id) })
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SectionHeader("Your competitions", "Open arena", onAction = onOpenArena)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SampleData.competitions.take(2).forEach { competition ->
                        CompetitionPreview(competition, onClick = onOpenArena)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(6.dp)) }
    }
}

@Composable
private fun StreakHero(streak: Int, onPlay: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(RushPurple, DeepPurple)))
            .clickable(onClick = onPlay)
            .padding(22.dp)
    ) {
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .size(94.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = .08f))
        )
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(17.dp))
                        .background(Color.White.copy(alpha = .16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.LocalFireDepartment, null, tint = Gold, modifier = Modifier.size(31.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("$streak day streak!", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text("You're on fire — keep it going", color = Color.White.copy(alpha = .75f), style = MaterialTheme.typography.bodyMedium)
                }
                Icon(Icons.Rounded.ArrowForward, null, tint = Color.White)
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = { .72f },
                    modifier = Modifier
                        .weight(1f)
                        .height(7.dp)
                        .clip(CircleShape),
                    color = Gold,
                    trackColor = Color.White.copy(alpha = .18f)
                )
                Spacer(Modifier.width(12.dp))
                Text("720 / 1,000 XP", color = Color.White, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun DailyChallengeCard(onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Mint.copy(alpha = .15f)),
                contentAlignment = Alignment.Center
            ) { Text("💡", fontSize = 30.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Definition Dash", style = MaterialTheme.typography.titleMedium)
                    Tag("+150 XP", Gold)
                }
                Spacer(Modifier.height(4.dp))
                Text("Match 8 words to their meanings", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Text("4 min  •  Medium", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
            }
            Icon(Icons.Rounded.ArrowForward, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun QuickModeCard(mode: PuzzleMode, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .width(158.dp)
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(mode.accent.copy(alpha = .14f)),
                contentAlignment = Alignment.Center
            ) { Text(mode.emoji, fontSize = 24.sp) }
            Spacer(Modifier.height(14.dp))
            Text(mode.title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(mode.difficulty, color = mode.accent, style = MaterialTheme.typography.labelMedium)
            if (mode.bestScore != null) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Bolt, null, modifier = Modifier.size(15.dp), tint = Gold)
                    Text(" Best ${mode.bestScore}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun CompetitionPreview(competition: Competition, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .width(270.dp)
            .clickable(onClick = onClick)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(competition.opponent, size = 42.dp, showStatus = true)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("vs ${competition.opponent.name}", style = MaterialTheme.typography.titleMedium)
                    Text(competition.category, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Tag(
                    if (competition.status == CompetitionStatus.YOUR_TURN) "YOUR TURN" else "WAITING",
                    if (competition.status == CompetitionStatus.YOUR_TURN) Coral else MaterialTheme.colorScheme.primary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${competition.yourScore}", style = MaterialTheme.typography.headlineMedium, color = Mint)
                Text("  —  ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${competition.opponentScore}", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.weight(1f))
                Text(competition.timeLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
