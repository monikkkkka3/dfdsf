package com.wordrush.app.ui.screens

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.SampleData
import com.wordrush.app.model.WordRound
import com.wordrush.app.ui.components.PrimaryAction
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.theme.Coral
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.Mint
import com.wordrush.app.ui.theme.RushPurple
import kotlinx.coroutines.delay
import java.util.Locale

@Composable
fun PuzzleGameScreen(modeId: String, onBack: () -> Unit) {
    val mode = SampleData.puzzleModes.firstOrNull { it.id == modeId } ?: SampleData.puzzleModes.first()
    val rounds = when (modeId) {
        "definition" -> SampleData.definitions
        "ladder" -> SampleData.ladderRounds
        else -> SampleData.anagrams
    }
    var roundIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var timeLeft by remember { mutableIntStateOf(if (modeId == "spelling") 75 else 60) }
    var answer by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<Boolean?>(null) }
    var showHint by remember { mutableStateOf(false) }
    var complete by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val round = rounds[roundIndex]

    LaunchedEffect(complete) {
        while (!complete && timeLeft > 0) {
            delay(1_000)
            timeLeft--
        }
        if (timeLeft == 0) complete = true
    }

    fun submit() {
        focus.clearFocus()
        val correct = answer.trim().equals(round.answer, ignoreCase = true)
        feedback = correct
        if (correct) score += (100 + timeLeft * 2 - if (showHint) 30 else 0).coerceAtLeast(50)
    }

    fun next() {
        if (roundIndex == rounds.lastIndex) {
            complete = true
        } else {
            roundIndex++
            answer = ""
            feedback = null
            showHint = false
        }
    }

    if (complete) {
        GameCompleteScreen(
            title = mode.title,
            score = score,
            correct = roundIndex + if (feedback == true) 1 else 0,
            total = rounds.size,
            onDone = onBack,
            onReplay = {
                roundIndex = 0
                score = 0
                timeLeft = if (modeId == "spelling") 75 else 60
                answer = ""
                feedback = null
                showHint = false
                complete = false
            }
        )
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        GameTopBar(
            title = mode.title,
            timeLeft = timeLeft,
            score = score,
            onBack = onBack
        )
        Spacer(Modifier.height(19.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ROUND ${roundIndex + 1} OF ${rounds.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.weight(1f))
            Text("${((roundIndex.toFloat() / rounds.size) * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { roundIndex.toFloat() / rounds.size },
            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
            color = RushPurple,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
        Spacer(Modifier.height(28.dp))

        GamePrompt(modeId = modeId, round = round)
        Spacer(Modifier.height(26.dp))

        OutlinedTextField(
            value = answer,
            onValueChange = { if (feedback != true) { answer = it; feedback = null } },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
            placeholder = { Text("Type your answer") },
            isError = feedback == false,
            supportingText = {
                when (feedback) {
                    true -> Text("Perfect! +${100 + timeLeft * 2 - if (showHint) 30 else 0} points", color = Mint)
                    false -> Text("Not quite — check the clue and try again.", color = MaterialTheme.colorScheme.error)
                    null -> if (showHint) Text("Hint: ${round.hint}", color = Gold)
                }
            },
            leadingIcon = {
                if (feedback != null) {
                    Icon(
                        if (feedback == true) Icons.Rounded.Check else Icons.Rounded.Refresh,
                        null,
                        tint = if (feedback == true) Mint else MaterialTheme.colorScheme.error
                    )
                }
            },
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (feedback == true) Mint else RushPurple,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                errorContainerColor = MaterialTheme.colorScheme.surface,
            ),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (answer.isNotBlank()) submit() })
        )

        Spacer(Modifier.height(15.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            Button(
                onClick = { showHint = true },
                enabled = !showHint && feedback != true,
                modifier = Modifier.height(54.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Rounded.Lightbulb, null, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
                Text("Hint")
            }
            PrimaryAction(
                text = if (feedback == true) "Next word" else "Submit",
                onClick = { if (feedback == true) next() else submit() },
                modifier = Modifier.weight(1f),
                enabled = answer.isNotBlank()
            )
        }

        Spacer(Modifier.height(23.dp))
        Surface(shape = RoundedCornerShape(19.dp), color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("💫", fontSize = 23.sp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Combo bonus", style = MaterialTheme.typography.titleMedium)
                    Text("Answer 3 in a row for +100 XP", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun GameTopBar(title: String, timeLeft: Int, score: Int, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(43.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
        ) { Icon(Icons.Rounded.Close, "Close game") }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text("Stay sharp!", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Tag("⏱  ${timeLeft / 60}:${(timeLeft % 60).toString().padStart(2, '0')}", if (timeLeft < 15) Coral else RushPurple)
        Spacer(Modifier.width(7.dp))
        Tag("⚡ $score", Gold)
    }
}

@Composable
private fun GamePrompt(modeId: String, round: WordRound) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 25.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val instruction = when (modeId) {
                "definition" -> "WHAT WORD FITS THIS DEFINITION?"
                "ladder" -> "COMPLETE THE WORD LADDER"
                "spelling" -> "LISTEN, THEN SPELL THE WORD"
                else -> "UNSCRAMBLE THE LETTERS"
            }
            Text(instruction, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(18.dp))
            when (modeId) {
                "spelling" -> SpellingSpeaker(round.answer)
                "ladder" -> {
                    Text(round.clue, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 8.dp))
                }
                "definition" -> {
                    Text("“${round.clue}”", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(horizontal = 8.dp))
                }
                else -> LetterTiles(round.scrambled)
            }
            if (modeId != "definition" && modeId != "ladder" && modeId != "spelling") {
                Spacer(Modifier.height(18.dp))
                Text(round.clue, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun LetterTiles(letters: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        letters.chunked(4).forEach { line ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                line.forEach { letter ->
                    Box(
                        Modifier
                            .size(53.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.surfaceVariant)
                                )
                            )
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .22f), RoundedCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(letter.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
private fun SpellingSpeaker(word: String) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.US
                tts = engine
            }
        }
        onDispose {
            engine?.stop()
            engine?.shutdown()
        }
    }
    Box(
        Modifier
            .size(94.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(RushPurple, Color(0xFF8B6BFF))))
            .clickable { tts?.speak(word, TextToSpeech.QUEUE_FLUSH, null, "solo_word") },
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.VolumeUp, "Play word", tint = Color.White, modifier = Modifier.size(42.dp)) }
    Spacer(Modifier.height(11.dp))
    Text("Tap to hear the word", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
}

@Composable
private fun GameCompleteScreen(
    title: String,
    score: Int,
    correct: Int,
    total: Int,
    onDone: () -> Unit,
    onReplay: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(112.dp).clip(CircleShape).background(Gold.copy(alpha = .19f)),
            contentAlignment = Alignment.Center
        ) { Text("🏆", fontSize = 58.sp) }
        Spacer(Modifier.height(23.dp))
        Text("Round complete!", style = MaterialTheme.typography.headlineLarge)
        Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(26.dp))
        Surface(shape = RoundedCornerShape(25.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(22.dp), horizontalArrangement = Arrangement.SpaceAround) {
                ResultStat(score.toString(), "SCORE")
                ResultStat("$correct/$total", "CORRECT")
                ResultStat("+$score", "XP")
            }
        }
        Spacer(Modifier.height(22.dp))
        PrimaryAction("Done", onDone, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onReplay,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(17.dp)
        ) { Text("Play again") }
    }
}

@Composable
private fun ResultStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineMedium)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
