package com.wordrush.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wordrush.app.model.PuzzleMode
import com.wordrush.app.model.SampleData
import com.wordrush.app.ui.components.Tag
import com.wordrush.app.ui.theme.DeepPurple
import com.wordrush.app.ui.theme.Gold
import com.wordrush.app.ui.theme.RushPurple

@Composable
fun PuzzlesScreen(onOpenPuzzle: (String) -> Unit) {
    var category by remember { mutableStateOf("All") }
    val categories = listOf("All", "Quick", "Daily", "Strategy", "Relaxed")

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PUZZLE LIBRARY", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Pick your brain boost", style = MaterialTheme.typography.headlineMedium)
                }
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Search, "Search puzzles") }
            }
        }

        item {
            Row(
                modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                categories.forEach { label ->
                    val selected = category == label
                    Text(
                        label,
                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) RushPurple else MaterialTheme.colorScheme.surface)
                            .clickable { category = label }
                            .padding(horizontal = 17.dp, vertical = 10.dp)
                    )
                }
            }
        }

        item { FeaturedPuzzle(onClick = { onOpenPuzzle("anagram") }) }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("All games", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Text("6 games", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        SampleData.puzzleModes.chunked(2).forEach { rowModes ->
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    rowModes.forEach { mode ->
                        PuzzleLibraryCard(
                            mode = mode,
                            modifier = Modifier.weight(1f),
                            onClick = { if (!mode.locked) onOpenPuzzle(mode.id) }
                        )
                    }
                    if (rowModes.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun FeaturedPuzzle(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(DeepPurple, RushPurple)))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column(Modifier.fillMaxWidth(.68f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tag("FEATURED", Gold, Gold.copy(alpha = .17f))
                Tag("2× XP", Color.White, Color.White.copy(alpha = .14f))
            }
            Spacer(Modifier.height(16.dp))
            Text("Anagram Rush", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(5.dp))
            Text("Unscramble 10 words before the clock runs out.", color = Color.White.copy(alpha = .75f), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(17.dp))
            Text("PLAY NOW  →", color = Gold, style = MaterialTheme.typography.labelLarge)
        }
        Text(
            "🔀",
            fontSize = 60.sp,
            modifier = Modifier.align(Alignment.CenterEnd)
        )
    }
}

@Composable
private fun PuzzleLibraryCard(mode: PuzzleMode, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
            .aspectRatio(.86f)
            .clickable(onClick = onClick)
    ) {
        Box(Modifier.padding(16.dp)) {
            Column {
                Box(
                    Modifier
                        .size(51.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(mode.accent.copy(alpha = .14f)),
                    contentAlignment = Alignment.Center
                ) { Text(mode.emoji, fontSize = 25.sp) }
                Spacer(Modifier.height(13.dp))
                Text(mode.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(5.dp))
                Text(mode.subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Tag(mode.difficulty, mode.accent)
                    if (mode.bestScore != null) {
                        Spacer(Modifier.width(6.dp))
                        Text("${mode.bestScore}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (mode.locked) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Lock, null, modifier = Modifier.size(16.dp)) }
            }
        }
    }
}
