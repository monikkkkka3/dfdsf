# WordRush keeps default Android optimization rules.
