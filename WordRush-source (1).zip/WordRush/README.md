# WordRush

WordRush is a polished Android MVP for word puzzles and friendly spelling competitions. It is built with Kotlin and Jetpack Compose and includes a playable offline/demo backend plus an optional Firebase source set for real accounts and synchronized social data.

## Included in the MVP

- Home dashboard with streaks, XP, daily challenge, and competition previews
- Puzzle library with Anagram Rush, Spelling Sprint, Word Ladder, Definition Dash, Word Hunt, and a locked daily mode
- Playable timed word rounds with hints, scoring, progress, and results
- Android Text-to-Speech pronunciation for spelling rounds
- Word Arena with follower presence, rankings, active/completed competitions, and quick match
- Three-step challenge creator: rival, game type, and round count
- Five-round spelling showdown with timers and a live-style scoreboard
- Player profile, achievements, progression, and settings presentation
- Light and dark Material 3 themes
- Demo and Firebase build flavors

## Install the ready-made demo

The project root contains `WordRush-demo.apk`, a debug-signed Android APK for testing. On a connected Android device:

```bash
adb install -r WordRush-demo.apk
```

Android 8.0 (API 26) or later is required.

## Open the source

1. Install current Android Studio with JDK 17.
2. Open the `WordRush` directory.
3. Let Gradle synchronize.
4. Select the `demoDebug` build variant.
5. Run on an emulator or Android device.

Command-line build:

```bash
./gradlew :app:assembleDemoDebug
```

The resulting APK is written to:

```text
app/build/outputs/apk/demo/debug/app-demo-debug.apk
```

## Firebase setup

The demo flavor has no server requirements. To activate the cloud adapter:

1. Create a Firebase Android app with package name `com.wordrush.app.cloud`.
2. Enable Authentication, Cloud Firestore, and Firebase Cloud Messaging.
3. Download `google-services.json` into `app/google-services.json`.
4. Select the `firebaseDebug` build variant.
5. Add sign-in/onboarding and connect screen ViewModels to `SocialRepository`.
6. Deploy the sample rules and indexes from the `firebase` directory after reviewing them for your production requirements.

Build the Firebase flavor:

```bash
./gradlew :app:assembleFirebaseDebug
```

`app/src/firebase` contains the Firestore implementation. `app/src/demo` supplies immediate local sample data. The UI shares the same `SocialRepository` contract in both variants.

### Suggested Firestore layout

```text
users/{uid}
users/{uid}/following/{followedUid}
competitions/{competitionId}
competitions/{competitionId}/rounds/{roundId}
leaderboards/{seasonId}/players/{uid}
```

Competition documents should include both player IDs, category, round count, status, timestamps, and server-validated scores. In a production competition, answers and score changes should be validated by a trusted Cloud Function or server rather than accepted directly from a phone.

## Important production work

The included APK is a functional UI/gameplay MVP using local sample followers. Before public release, add:

- Google/email authentication and account recovery
- ViewModels that collect Firebase repository data
- Cloud Functions for invites, round assignment, answer validation, and anti-cheat scoring
- Push notification token registration and challenge notifications
- Firestore security-rule tests
- App Check, Crashlytics, analytics consent, and privacy controls
- Play Store signing, screenshots, privacy policy, and accessibility review

## Technology

- Kotlin 2.0
- Jetpack Compose + Material 3
- Navigation Compose
- Android Text-to-Speech
- Firebase Auth, Firestore, and Messaging in the optional cloud flavor
- Minimum Android API 26; target API 35
